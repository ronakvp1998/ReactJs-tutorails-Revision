export const sum = (a, b) => a + b;

/**
 *
 *  Different Type of Testing??
 *  - Manual Testing
 *  - Autmation Testing
 *      - Selenium Testing
 *
 *
 *  - E2E Testing - Covers entire user Journey
 *
 *  - Unit Testing
 *  - Integration Testing
 *
 *
 *
 *
 * - Install React Testing Librabry
 * - Install Jest
 * - configure Jest
 * - Installed jest-environment-jsdom
 * - Create my first test
 * - Configure babel
 * - Wrote expect sum test
 * - gitignore coverage report
 *
 *
 *
 *
 *
 *
 *
 */
