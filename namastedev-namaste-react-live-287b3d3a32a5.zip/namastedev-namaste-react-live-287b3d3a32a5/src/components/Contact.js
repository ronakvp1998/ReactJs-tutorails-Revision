const Contact = () => {
  return <h1>Contact Us Page</h1>;
};

export default Contact;
