export default "dummy.png";
